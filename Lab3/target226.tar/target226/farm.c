/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_430(unsigned x)
{
    return x + 2488830706U;
}

void setval_404(unsigned *p)
{
    *p = 3347646639U;
}

void setval_185(unsigned *p)
{
    *p = 3284633928U;
}

unsigned addval_125(unsigned x)
{
    return x + 3344452527U;
}

unsigned addval_418(unsigned x)
{
    return x + 2428995912U;
}

void setval_154(unsigned *p)
{
    *p = 3281016906U;
}

unsigned addval_464(unsigned x)
{
    return x + 3281016928U;
}

unsigned getval_399()
{
    return 2428996936U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_287(unsigned *p)
{
    *p = 3374370441U;
}

unsigned getval_289()
{
    return 3221803393U;
}

unsigned getval_377()
{
    return 3224421001U;
}

void setval_127(unsigned *p)
{
    *p = 3374370445U;
}

unsigned addval_264(unsigned x)
{
    return x + 3222851209U;
}

void setval_130(unsigned *p)
{
    *p = 2430634312U;
}

unsigned getval_278()
{
    return 3526414729U;
}

unsigned addval_408(unsigned x)
{
    return x + 3281047945U;
}

unsigned getval_288()
{
    return 3264266889U;
}

unsigned addval_166(unsigned x)
{
    return x + 2425406089U;
}

void setval_128(unsigned *p)
{
    *p = 3526935177U;
}

unsigned addval_444(unsigned x)
{
    return x + 3374894729U;
}

unsigned getval_422()
{
    return 2464188744U;
}

void setval_359(unsigned *p)
{
    *p = 3515691699U;
}

unsigned addval_425(unsigned x)
{
    return x + 3348156041U;
}

void setval_454(unsigned *p)
{
    *p = 3255412298U;
}

unsigned getval_265()
{
    return 3222851209U;
}

void setval_172(unsigned *p)
{
    *p = 3674784385U;
}

unsigned getval_381()
{
    return 2495777239U;
}

unsigned addval_386(unsigned x)
{
    return x + 3353381192U;
}

unsigned getval_417()
{
    return 3767027937U;
}

unsigned addval_138(unsigned x)
{
    return x + 3353381192U;
}

void setval_302(unsigned *p)
{
    *p = 3252717896U;
}

void setval_233(unsigned *p)
{
    *p = 3767093476U;
}

unsigned getval_412()
{
    return 3372797641U;
}

unsigned getval_259()
{
    return 3286272332U;
}

void setval_316(unsigned *p)
{
    *p = 2428669202U;
}

unsigned getval_384()
{
    return 3515462938U;
}

unsigned getval_469()
{
    return 3222851977U;
}

unsigned getval_108()
{
    return 3229929929U;
}

unsigned getval_217()
{
    return 3223375497U;
}

unsigned addval_428(unsigned x)
{
    return x + 3381973385U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
